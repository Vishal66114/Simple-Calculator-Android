# Simple Calculator Android

A lightweight offline Android calculator built with Kotlin and Jetpack Compose.

## Features
- Addition, subtraction, multiplication and division
- Percentage, decimal input, sign toggle, clear and delete
- Expression parser with operator precedence and parentheses support
- Division-by-zero and invalid-expression handling
- No network permission and no ads

## Build APK
Open this project in Android Studio and run:
```bash
gradle assembleDebug
```
APK output:
`app/build/outputs/apk/debug/app-debug.apk`

## Build on GitHub from a phone
1. Upload this project to a GitHub repository on the `main` branch.
2. Open the repository's Actions tab.
3. Run **Build Android APK** (or let a push trigger it).
4. Open the completed workflow run and download the `SimpleCalculator-debug-apk` artifact.
5. Extract the ZIP and install `app-debug.apk` on Android.
