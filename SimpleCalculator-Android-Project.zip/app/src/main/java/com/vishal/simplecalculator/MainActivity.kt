package com.vishal.simplecalculator

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF101114)
private val Panel = Color(0xFF1B1D22)
private val Operator = Color(0xFF315EFB)
private val Accent = Color(0xFFFFA726)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CalculatorScreen() }
    }
}

@Composable
fun CalculatorScreen() {
    var expression by remember { mutableStateOf("") }
    var result by remember { mutableStateOf("0") }
    var error by remember { mutableStateOf(false) }

    fun press(key: String) {
        error = false
        when (key) {
            "AC" -> { expression = ""; result = "0" }
            "DEL" -> expression = expression.dropLast(1)
            "=" -> {
                if (expression.isNotBlank()) {
                    try {
                        result = Calculator.evaluate(expression).formatResult()
                        expression = result
                    } catch (_: Exception) {
                        error = true
                        result = "Error"
                    }
                }
            }
            else -> {
                if (expression.length < 40) expression += key
            }
        }
    }

    val rows = listOf(
        listOf("AC", "DEL", "%", "÷"),
        listOf("7", "8", "9", "×"),
        listOf("4", "5", "6", "−"),
        listOf("1", "2", "3", "+"),
        listOf("±", "0", ".", "=")
    )

    MaterialTheme {
        Column(
            modifier = Modifier.fillMaxSize().background(Bg).padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("SIMPLE CALCULATOR", color = Color.LightGray, fontSize = 14.sp,
                fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 18.dp))
            Spacer(Modifier.weight(1f))
            Text(expression.ifEmpty { "0" }, color = Color.White, fontSize = 36.sp,
                textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth(),
                maxLines = 2)
            Text(if (error) "Invalid expression" else "= $result",
                color = if (error) Color.Red else Color(0xFFB8C0D9),
                fontSize = 24.sp, textAlign = TextAlign.End,
                modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(12.dp))
            rows.forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()) {
                    row.forEach { key ->
                        val isOperator = key in listOf("÷", "×", "−", "+", "=")
                        val isUtility = key in listOf("AC", "DEL", "%", "±")
                        Button(
                            onClick = {
                                if (key == "±") {
                                    if (expression.startsWith("-")) expression = expression.drop(1)
                                    else if (expression.isNotEmpty()) expression = "-$expression"
                                } else press(key)
                            },
                            modifier = Modifier.weight(1f).height(68.dp),
                            shape = RoundedCornerShape(20.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = when {
                                    isOperator -> Operator
                                    isUtility -> Color(0xFF343840)
                                    else -> Panel
                                },
                                contentColor = if (isOperator) Color.White else Color(0xFFF5F5F5)
                            ),
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Text(key, fontSize = if (key.length > 2) 17.sp else 24.sp,
                                fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
            Text("Works offline • No ads • No permissions",
                color = Color.Gray, fontSize = 12.sp,
                modifier = Modifier.align(Alignment.CenterHorizontally).padding(8.dp))
        }
    }
}

private fun Double.formatResult(): String {
    if (!isFinite()) throw IllegalArgumentException("Not finite")
    val rounded = if (kotlin.math.abs(this - kotlin.math.round(this)) < 1e-10)
        kotlin.math.round(this).toLong().toString()
    else String.format(java.util.Locale.US, "%.8f", this).trimEnd('0').trimEnd('.')
    return rounded
}

private object Calculator {
    fun evaluate(source: String): Double {
        val s = source.replace("×", "*").replace("÷", "/").replace("−", "-")
            .replace("%", "/100")
        var pos = 0
        fun skip() { while (pos < s.length && s[pos].isWhitespace()) pos++ }
        lateinit var expr: () -> Double
        lateinit var term: () -> Double
        lateinit var factor: () -> Double
        factor = {
            skip()
            when {
                pos < s.length && s[pos] == '+' -> { pos++; factor() }
                pos < s.length && s[pos] == '-' -> { pos++; -factor() }
                pos < s.length && s[pos] == '(' -> {
                    pos++; val v = expr(); skip()
                    require(pos < s.length && s[pos] == ')')
                    pos++; v
                }
                else -> {
                    val start = pos
                    while (pos < s.length && (s[pos].isDigit() || s[pos] == '.')) pos++
                    require(pos > start)
                    s.substring(start, pos).toDouble()
                }
            }
        }
        term = {
            var v = factor()
            while (true) {
                skip()
                if (pos < s.length && (s[pos] == '*' || s[pos] == '/')) {
                    val op = s[pos++]; val rhs = factor()
                    if (op == '/') require(rhs != 0.0)
                    v = if (op == '*') v * rhs else v / rhs
                } else break
            }
            v
        }
        expr = {
            var v = term()
            while (true) {
                skip()
                if (pos < s.length && (s[pos] == '+' || s[pos] == '-')) {
                    val op = s[pos++]; val rhs = term()
                    v = if (op == '+') v + rhs else v - rhs
                } else break
            }
            v
        }
        val value = expr()
        skip()
        require(pos == s.length)
        return value
    }
}
